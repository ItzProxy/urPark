<script type="text/javascript" src="js/bootstrap.js"></script>
<script
	src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-1">
			<div class="container-fluid">
				<p>Selection:</p>
			</div>
		</div>
		<div class="col-sm-2">
			<div class="dropdown">
				<a id="dLabel" data-target="#" href="#" data-toggle="dropdown"
					role="button" aria-haspopup="true" aria-expanded="true">
					Dropdown trigger <span class="caret"></span>
				</a>
				<ul class="dropdown-menu" aria-labelledby="dLabel">
					<li><a href="https://google.ca">Google</a></li>
				</ul>
			</div>
		</div>
		<div class="col-sm-2">
			<div class="dropdown">
				<a id="dLabel" data-target="#" href="#" data-toggle="dropdown"
					role="button" aria-haspopup="true" aria-expanded="true">
					Dropdown trigger <span class="caret"></span>
				</a>
				<ul class="dropdown-menu" aria-labelledby="dLabel">
					<li><a href="https://google.ca">Google</a></li>
				</ul>
			</div>
		</div>
		<div><span class="glyphicon glyphicon-time"></span></div>
		<div class="col-sm-2">
			<div class="dropdown">
				<a id="dLabel" data-target="#" href="#" data-toggle="dropdown"
					role="button" aria-haspopup="true" aria-expanded="true">
					Dropdown trigger <span class="caret"></span>
				</a>
				<ul class="dropdown-menu" aria-labelledby="dLabel">
					<li><a href="https://google.ca">Google</a></li>
				</ul>
			</div>
		</div>
		<div class="col-sm-2">
			<div class="dropdown">
				<a id="dLabel" data-target="#" href="#" data-toggle="dropdown"
					role="button" aria-haspopup="true" aria-expanded="true">
					Dropdown trigger <span class="caret"></span>
				</a>
				<ul class="dropdown-menu" aria-labelledby="dLabel">
					<li><a href="https://google.ca">Google</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>